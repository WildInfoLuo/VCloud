function showH(){
	$("#navbar_hidden").css("display","block");  
	$("#f-icon")[0].src="../images/up.png";
}
function hiddenH(){
	$("#navbar_hidden").hide();
	$("#f-icon")[0].src="../images/down.png";
}